import os
import logging
import sqlite3
import io
import random
from datetime import datetime, timedelta
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter

# Загружаем конфиг
load_dotenv()
TOKEN = os.getenv('BOT_TOKEN')

# ==================== НАСТРОЙКИ БРЕНДБУКА ====================
BRAND_COLORS = {
    "dark_green": (5, 40, 45),  # Pantone 5463 C - темно-зеленый
    "green": (0, 100, 85),  # Pantone 568 C - зеленый
    "emerald": (0, 175, 150),  # Pantone 3268 C - изумрудный
    "yellow": (245, 230, 70),  # Pantone 101 C - желтый
    "black": (0, 0, 0),  # Pantone Black C - черный
    "white": (255, 255, 255),
}

# ПУТИ К ФОТО ЖИВОТНЫХ
ANIMAL_PHOTOS = {
    'тигр': 'animals/tiger.jpg',
    'медведь': 'animals/bear.jpg',
    'панда': 'animals/panda.jpg',
    'лиса': 'animals/fox.jpg',
    'волк': 'animals/wolf.jpg',
    'обезьяна': 'animals/monkey.jpg'
}

# ШРИФТЫ
FONT_REGULAR = "arial.ttf"
FONT_BOLD = "arialbd.ttf"
FONT_HEADER = "arialbd.ttf"


# ==================== НАСТРОЙКА ЛОГИРОВАНИЯ ====================
def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    file_handler = logging.FileHandler('zoo_bot_analytics.log', encoding='utf-8')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


logger = setup_logging()


# ==================== БАЗА ДАННЫХ ====================
def init_database():
    conn = sqlite3.connect('moscow_zoo_bot.db')
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS quiz_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            animal_type TEXT,
            scores TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            message TEXT,
            rating INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    conn.commit()
    conn.close()
    logger.info("База данных инициализирована")


def save_quiz_result(user_id: int, animal: str, scores: dict):
    try:
        conn = sqlite3.connect('moscow_zoo_bot.db')
        cursor = conn.cursor()

        cursor.execute(
            'INSERT OR IGNORE INTO users (user_id) VALUES (?)',
            (user_id,)
        )

        cursor.execute(
            '''INSERT INTO quiz_results (user_id, animal_type, scores) 
               VALUES (?, ?, ?)''',
            (user_id, animal, str(scores))
        )

        conn.commit()
        conn.close()
        logger.info(f"Результат сохранен: {user_id} -> {animal}")
    except Exception as e:
        logger.error(f"Ошибка сохранения: {e}")


# ==================== ДАННЫЕ ВИКТОРИНЫ ====================
QUESTIONS = [
    {
        'id': 1,
        'text': 'Какой ваш идеальный выходной?',
        'answers': [
            {'text': '🏔️ Активный поход в горы', 'weights': {'тигр': 3, 'медведь': 2}},
            {'text': '📚 Тихий вечер с книгой', 'weights': {'панда': 3, 'лиса': 1}},
            {'text': '🎉 Вечеринка с друзьями', 'weights': {'обезьяна': 3, 'волк': 1}},
            {'text': '🧭 Исследование нового места', 'weights': {'волк': 2, 'лиса': 2}},
        ]
    },
    {
        'id': 2,
        'text': 'Ваша суперсила?',
        'answers': [
            {'text': '💪 Сила и решительность', 'weights': {'тигр': 3, 'медведь': 2}},
            {'text': '🧠 Мудрость и хитрость', 'weights': {'лиса': 3, 'волк': 2}},
            {'text': '🤝 Дружелюбие и общительность', 'weights': {'панда': 2, 'обезьяна': 3}},
            {'text': '⚡ Свобода и скорость', 'weights': {'волк': 3, 'тигр': 1}},
        ]
    },
    {
        'id': 3,
        'text': 'Какой стиль общения вам ближе?',
        'answers': [
            {'text': '🎯 Прямой и четкий', 'weights': {'тигр': 3, 'волк': 2}},
            {'text': '🦊 Дипломатичный и гибкий', 'weights': {'лиса': 3, 'панда': 1}},
            {'text': '🐻 Спокойный и уверенный', 'weights': {'медведь': 3, 'панда': 2}},
            {'text': '🐵 Энергичный и веселый', 'weights': {'обезьяна': 3, 'тигр': 1}},
        ]
    }
]

ANIMALS_INFO = {
    'тигр': {
        'name': 'Амурский тигр',
        'scientific': 'Panthera tigris altaica',
        'desc': 'Сильный, независимый лидер с прекрасными стратегическими способностями.',
        'program': 'Программа опеки поддерживает сохранение редчайшей кошки планеты.',
        'emoji': '🐯',
        'fact': 'Амурский тигр — самый крупный подвид тигра в мире.',
        'photo': 'tiger.jpg'
    },
    'медведь': {
        'name': 'Бурый медведь',
        'scientific': 'Ursus arctos',
        'desc': 'Мудрый и уверенный защитник, умеющий находить решения в сложных ситуациях.',
        'program': 'Опекая медведя, вы помогаете обеспечить его зимнюю спячку.',
        'emoji': '🐻',
        'fact': 'Бурый медведь может бегать со скоростью до 50 км/ч.',
        'photo': 'bear.jpg'
    },
    'панда': {
        'name': 'Большая панда',
        'scientific': 'Ailuropoda melanoleuca',
        'desc': 'Добродушный и спокойный философ, ценящий гармонию и уют.',
        'program': 'Международные программы по сохранению этого уникального вида.',
        'emoji': '🐼',
        'fact': 'Панды проводят до 14 часов в день за едой.',
        'photo': 'panda.jpg'
    },
    'лиса': {
        'name': 'Рыжая лиса',
        'scientific': 'Vulpes vulpes',
        'desc': 'Хитрый и изобретательный стратег с быстрой адаптацией к изменениям.',
        'program': 'Программа реабилитации животных в природной среде.',
        'emoji': '🦊',
        'fact': 'Лисы используют магнитное поле Земли для охоты.',
        'photo': 'fox.jpg'
    },
    'волк': {
        'name': 'Полярный волк',
        'scientific': 'Canis lupus arctos',
        'desc': 'Свободолюбивый и преданный член стаи, ценящий независимость.',
        'program': 'Исследования поведения этих умных социальных животных.',
        'emoji': '🐺',
        'fact': 'Волки могут слышать звуки на расстоянии до 10 км.',
        'photo': 'wolf.jpg'
    },
    'обезьяна': {
        'name': 'Яванская макака',
        'scientific': 'Macaca fascicularis',
        'desc': 'Общительный и энергичный исследователь, душа любой компании.',
        'program': 'Обогащение среды и ветеринарный уход за приматами.',
        'emoji': '🐵',
        'fact': 'Макаки используют инструменты для добычи пищи.',
        'photo': 'monkey.jpg'
    }
}


# ==================== СОЗДАНИЕ ИЗОБРАЖЕНИЙ С ФОТО ====================
def create_animal_photo_image(animal_info: dict, user_name: str) -> io.BytesIO:
    """
    Создает изображение с ФОТО животного в фирменном стиле
    """
    width, height = 800, 600  # Увеличили высоту для фото

    # === 1. ПРОБУЕМ ЗАГРУЗИТЬ ФОТО ЖИВОТНОГО ===
    photo_path = f"animals/{animal_info['photo']}"
    try:
        # Загружаем фото животного
        animal_photo = Image.open(photo_path)

        # Обрабатываем фото
        animal_photo = animal_photo.convert('RGB')

        # Автоматическое кадрирование и ресайз
        # Сохраняем пропорции, но обрезаем под нужный размер
        target_width = 800
        target_height = 400

        # Масштабируем с сохранением пропорций
        img_ratio = animal_photo.width / animal_photo.height
        target_ratio = target_width / target_height

        if img_ratio > target_ratio:
            # Широкое фото - обрезаем по ширине
            new_height = target_height
            new_width = int(new_height * img_ratio)
            animal_photo = animal_photo.resize((new_width, new_height), Image.Resampling.LANCZOS)
            # Центрируем
            left = (new_width - target_width) // 2
            animal_photo = animal_photo.crop((left, 0, left + target_width, target_height))
        else:
            # Высокое фото - обрезаем по высоте
            new_width = target_width
            new_height = int(new_width / img_ratio)
            animal_photo = animal_photo.resize((new_width, new_height), Image.Resampling.LANCZOS)
            # Центрируем
            top = (new_height - target_height) // 2
            animal_photo = animal_photo.crop((0, top, target_width, top + target_height))

        # Улучшаем фото
        enhancer = ImageEnhance.Contrast(animal_photo)
        animal_photo = enhancer.enhance(1.2)

        # Создаем градиентную маску для плавного перехода
        gradient = Image.new('L', (target_width, 100), color=0)
        draw_gradient = ImageDraw.Draw(gradient)
        for i in range(100):
            alpha = int(255 * (i / 100))
            draw_gradient.line([(0, i), (target_width, i)], fill=alpha)

        photo_ready = True

    except Exception as e:
        logger.warning(f"Не удалось загрузить фото {animal_info['photo']}: {e}")
        # Создаем заглушку с цветом
        animal_photo = Image.new('RGB', (800, 400), color=BRAND_COLORS["green"])
        draw_placeholder = ImageDraw.Draw(animal_photo)
        draw_placeholder.text((400, 200), animal_info['emoji'],
                              fill=BRAND_COLORS["white"],
                              font=ImageFont.load_default(),
                              anchor="mm")
        photo_ready = False

    # === 2. СОЗДАЕМ ОСНОВНОЕ ИЗОБРАЖЕНИЕ ===
    # Создаем основное изображение с темно-зеленым фоном
    main_img = Image.new('RGB', (width, height), color=BRAND_COLORS["dark_green"])
    draw = ImageDraw.Draw(main_img)

    # Загружаем шрифты
    try:
        font_large = ImageFont.truetype(FONT_BOLD, 32)
        font_medium = ImageFont.truetype(FONT_REGULAR, 22)
        font_small = ImageFont.truetype(FONT_REGULAR, 18)
        font_scientific = ImageFont.truetype(FONT_REGULAR, 20)
    except:
        font_large = ImageFont.load_default()
        font_medium = ImageFont.load_default()
        font_small = ImageFont.load_default()
        font_scientific = ImageFont.load_default()

    # === 3. ВСТАВЛЯЕМ ФОТО ЖИВОТНОГО ===
    # Накладываем фото на верхнюю часть
    main_img.paste(animal_photo, (0, 0))

    # Темный оверлей для лучшей читаемости текста на фото
    overlay = Image.new('RGBA', (width, 150), (5, 40, 45, 200))  # Темно-зеленый с прозрачностью
    main_img.paste(overlay, (0, 0), overlay)

    # === 4. ТЕКСТ ПОВЕРХ ФОТО ===
    # Заголовок поверх фото
    title = f"{user_name}, ваше тотемное животное!"
    title_bbox = draw.textbbox((0, 0), title, font=font_large)
    title_width = title_bbox[2] - title_bbox[0]
    draw.text(
        ((width - title_width) // 2, 20),
        title,
        fill=BRAND_COLORS["white"],
        font=font_large
    )

    # Название животного поверх фото
    animal_title = f"{animal_info['emoji']}  {animal_info['name']}"
    animal_bbox = draw.textbbox((0, 0), animal_title, font=font_large)
    animal_width = animal_bbox[2] - animal_bbox[0]
    draw.text(
        ((width - animal_width) // 2, 70),
        animal_title,
        fill=BRAND_COLORS["yellow"],
        font=font_large
    )

    # === 5. ТЕКСТОВАЯ ЧАСТЬ ПОД ФОТО ===
    y_position = 420

    # Научное название
    scientific = animal_info['scientific']
    sci_bbox = draw.textbbox((0, 0), scientific, font=font_scientific)
    sci_width = sci_bbox[2] - sci_bbox[0]
    draw.text(
        ((width - sci_width) // 2, y_position),
        scientific,
        fill=BRAND_COLORS["emerald"],
        font=font_scientific
    )
    y_position += 40

    # Разделительная линия
    draw.line([(50, y_position), (width - 50, y_position)],
              fill=BRAND_COLORS["emerald"], width=2)
    y_position += 30

    # Описание животного
    description = animal_info['desc']
    # Разбиваем длинный текст
    words = description.split()
    lines = []
    current_line = []

    for word in words:
        test_line = ' '.join(current_line + [word])
        bbox = draw.textbbox((0, 0), test_line, font=font_medium)
        if bbox[2] - bbox[0] < width - 100:
            current_line.append(word)
        else:
            lines.append(' '.join(current_line))
            current_line = [word]
    if current_line:
        lines.append(' '.join(current_line))

    for line in lines:
        draw.text(
            (50, y_position),
            line,
            fill=BRAND_COLORS["white"],
            font=font_medium
        )
        y_position += 30

    y_position += 20

    # Интересный факт в рамке
    fact_text = f"Знаете ли вы? {animal_info['fact']}"
    # Разбиваем факт
    fact_words = fact_text.split()
    fact_lines = []
    current_fact_line = []

    for word in fact_words:
        test_fact_line = ' '.join(current_fact_line + [word])
        bbox = draw.textbbox((0, 0), test_fact_line, font=font_small)
        if bbox[2] - bbox[0] < width - 120:
            current_fact_line.append(word)
        else:
            fact_lines.append(' '.join(current_fact_line))
            current_fact_line = [word]
    if current_fact_line:
        fact_lines.append(' '.join(current_fact_line))

    # Вычисляем высоту блока с фактом
    fact_height = len(fact_lines) * 25 + 20

    # Рисуем рамку
    draw.rectangle([40, y_position, width - 40, y_position + fact_height],
                   fill=BRAND_COLORS["green"],
                   outline=BRAND_COLORS["emerald"],
                   width=2)

    # Текст в рамке
    for i, line in enumerate(fact_lines):
        draw.text(
            (50, y_position + 10 + i * 25),
            line,
            fill=BRAND_COLORS["white"],
            font=font_small
        )

    y_position += fact_height + 20

    # === 6. ФУТЕР С ЛОГОТИПОМ ===
    # Текст про программу опеки
    draw.text(
        (50, y_position),
        "Программа опеки животных",
        fill=BRAND_COLORS["yellow"],
        font=font_medium
    )

    draw.text(
        (50, y_position + 30),
        "155 лет Московскому зоопарку (с 1864 года)",
        fill=BRAND_COLORS["emerald"],
        font=font_small
    )

    # Логотип зоопарка (справа внизу)
    try:
        logo = Image.open("logo_moscow_zoo.png")
        logo = logo.resize((100, 100))
        main_img.paste(logo, (width - 120, y_position - 20), logo)
    except:
        # Текстовый логотип
        draw.text(
            (width - 200, y_position),
            "Московский\nзоопарк",
            fill=BRAND_COLORS["emerald"],
            font=font_small,
            align="right"
        )

    # === 7. ВОДЯНОЙ ЗНАК ===
    # Полупрозрачный текст в углу
    watermark = Image.new('RGBA', main_img.size, (0, 0, 0, 0))
    watermark_draw = ImageDraw.Draw(watermark)

    watermark_text = f"© Московский зоопарк, 2024"
    watermark_draw.text(
        (width - 10, height - 10),
        watermark_text,
        fill=(255, 255, 255, 100),  # Полупрозрачный белый
        font=font_small,
        anchor="rs"
    )

    main_img = Image.alpha_composite(main_img.convert('RGBA'), watermark).convert('RGB')

    # Конвертируем в байты
    img_byte_arr = io.BytesIO()
    main_img.save(img_byte_arr, format='JPEG', quality=90, optimize=True)
    img_byte_arr.seek(0)

    return img_byte_arr


# ==================== КЛАСС СЕССИЙ ====================
class UserSession:
    def __init__(self):
        self.sessions = {}

    def get_or_create(self, user_id: int):
        if user_id not in self.sessions:
            self.sessions[user_id] = {
                'scores': {animal: 0 for animal in ANIMALS_INFO.keys()},
                'current_question': 0,
                'started_at': datetime.now(),
                'result_animal': None
            }
        return self.sessions[user_id]

    def reset(self, user_id: int):
        if user_id in self.sessions:
            self.sessions[user_id] = {
                'scores': {animal: 0 for animal in ANIMALS_INFO.keys()},
                'current_question': 0,
                'started_at': datetime.now(),
                'result_animal': None
            }


user_sessions = UserSession()


# ==================== ОБРАБОТЧИКИ ====================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_sessions.reset(user_id)

    welcome_text = (
        "🐾 *Добро пожаловать в Московский зоопарк!*\n\n"
        "В 2024 году нам исполняется *155 лет* — мы сохраняем природу с 1864 года!\n\n"
        "*Определите ваше тотемное животное*\n"
        "Всего 3 вопроса — и вы узнаете, какое животное\n"
        "наиболее соответствует вашему характеру!\n\n"
        "В конце вы получите персональное изображение\n"
        "с вашим животным в фирменном стиле зоопарка."
    )

    keyboard = [[InlineKeyboardButton("🎮 Начать викторину", callback_data='start_quiz')]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        welcome_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

    logger.info(f"Старт: {user_id}")


async def show_question(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int):
    session = user_sessions.get_or_create(user_id)
    q_index = session['current_question']

    if q_index >= len(QUESTIONS):
        await finish_quiz(update, context, user_id)
        return

    question = QUESTIONS[q_index]
    keyboard = []

    for i, answer in enumerate(question['answers']):
        keyboard.append([InlineKeyboardButton(
            answer['text'],
            callback_data=f'answer_{q_index}_{i}'
        )])

    reply_markup = InlineKeyboardMarkup(keyboard)

    question_text = (
        f"*Вопрос {q_index + 1}/{len(QUESTIONS)}*\n\n"
        f"{question['text']}"
    )

    if update.callback_query:
        await update.callback_query.edit_message_text(
            question_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text(
            question_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )


async def handle_answer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = update.effective_user.id
    session = user_sessions.get_or_create(user_id)

    _, q_index_str, a_index_str = query.data.split('_')
    q_index = int(q_index_str)
    a_index = int(a_index_str)

    answer_data = QUESTIONS[q_index]['answers'][a_index]
    for animal, weight in answer_data['weights'].items():
        session['scores'][animal] = session['scores'].get(animal, 0) + weight

    session['current_question'] += 1
    await show_question(update, context, user_id)


async def finish_quiz(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int):
    session = user_sessions.get_or_create(user_id)
    scores = session['scores']

    result_animal = max(scores, key=scores.get)
    animal_info = ANIMALS_INFO[result_animal]
    session['result_animal'] = result_animal

    save_quiz_result(user_id, result_animal, scores)

    # СОЗДАЕМ ИЗОБРАЖЕНИЕ С ФОТО ЖИВОТНОГО
    user_name = update.effective_user.first_name
    image_bytes = create_animal_photo_image(animal_info, user_name)

    # Текст для шеринга
    share_text = (
        f"Я прошел викторину Московского зоопарка и мое тотемное животное — "
        f"{animal_info['name']} {animal_info['emoji']}!\n\n"
        f"Московский зоопарк — 155 лет сохраняем природу!\n"
        f"Пройди викторину: @{(await context.bot.get_me()).username}"
    )

    # Клавиатура
    keyboard = [
        [
            InlineKeyboardButton("📱 Поделиться в Telegram",
                                 url=f"https://t.me/share/url?url=&text={share_text}"),
            InlineKeyboardButton("📘 VK",
                                 url=f"https://vk.com/share.php?url=&title={share_text}")
        ],
        [
            InlineKeyboardButton("✉️ Связаться о программе опеки",
                                 callback_data=f'contact_{result_animal}')
        ],
        [
            InlineKeyboardButton("🔄 Пройти еще раз", callback_data='restart'),
            InlineKeyboardButton("⭐ Оценить бота", callback_data='rate_bot')
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Текст результата
    result_text = (
        f"🎉 *Поздравляем, {user_name}!*\n\n"
        f"*Ваше тотемное животное:* {animal_info['name']} {animal_info['emoji']}\n\n"
        f"*Научное название:* {animal_info['scientific']}\n\n"
        f"*Описание характера:*\n{animal_info['desc']}\n\n"
        f"*Программа опеки:*\n{animal_info['program']}\n\n"
        f"*Интересный факт:* {animal_info['fact']}\n\n"
        f"На изображении выше — {animal_info['name'].split()[0]} "
        f"из коллекции Московского зоопарка!"
    )

    # Отправляем фото
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo=image_bytes,
        caption=result_text,
        parse_mode='Markdown',
        reply_markup=reply_markup
    )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id

    if query.data == 'start_quiz':
        user_sessions.reset(user_id)
        await show_question(update, context, user_id)

    elif query.data.startswith('answer_'):
        await handle_answer(update, context)

    elif query.data == 'restart':
        user_sessions.reset(user_id)
        await query.message.reply_text(
            "🔄 *Начинаем заново!*\n\n"
            "Давайте определим ваше тотемное животное еще раз!",
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Первый вопрос →", callback_data='start_quiz')]])
        )

    elif query.data.startswith('contact_'):
        animal = query.data.split('_')[1]
        animal_info = ANIMALS_INFO[animal]

        contact_text = (
            f"📞 *Контакты Московского зоопарка*\n\n"
            f"*Для связи по программе опеки {animal_info['name'].split()[0]}:*\n\n"
            f"📧 Email: partner@moscowzoo.ru\n"
            f"📞 Телефон: +7 (499) 255-00-93\n"
            f"🌐 Сайт: https://moscowzoo.ru/programs/guardianship\n\n"
            f"*Ваше животное:* {animal_info['name']} {animal_info['emoji']}\n"
            f"*Научное название:* {animal_info['scientific']}\n\n"
            f"Сообщите нашим специалистам результат викторины для\n"
            f"персонализированной консультации по программе опеки."
        )

        await query.message.reply_text(
            contact_text,
            parse_mode='Markdown'
        )

    elif query.data == 'rate_bot':
        keyboard = [
            [InlineKeyboardButton("⭐", callback_data='rate_1'),
             InlineKeyboardButton("⭐⭐", callback_data='rate_2'),
             InlineKeyboardButton("⭐⭐⭐", callback_data='rate_3'),
             InlineKeyboardButton("⭐⭐⭐⭐", callback_data='rate_4'),
             InlineKeyboardButton("⭐⭐⭐⭐⭐", callback_data='rate_5')]
        ]
        await query.message.reply_text(
            "💬 *Обратная связь*\n\n"
            "Пожалуйста, оцените бота от 1 до 5 звезд:",
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif query.data.startswith('rate_'):
        rating = int(query.data.split('_')[1])
        await query.edit_message_text(
            f"Спасибо за оценку {rating}⭐! Ваш отзыв помогает нам становиться лучше!"
        )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = (
        "🆘 *Справочная информация*\n\n"
        "*Доступные команды:*\n"
        "▫️ /start — начать викторину\n"
        "▫️ /contact — контакты зоопарка\n"
        "▫️ /help — эта справка\n\n"
        "*Как работает викторина:*\n"
        "1. Ответьте на 3 вопроса\n"
        "2. Получите персональное животное\n"
        "3. Узнайте интересные факты\n"
        "4. Получите изображение с фото животного\n\n"
        "*Фото животных:*\n"
        "Все фото взяты из коллекции Московского зоопарка."
    )

    await update.message.reply_text(help_text, parse_mode='Markdown')


async def contact_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    contact_text = (
        "📞 *Контакты Московского зоопарка*\n\n"
        "*Общая информация:*\n"
        "📧 Email: info@moscowzoo.ru\n"
        "📞 Телефон: +7 (499) 255-00-93\n"
        "🌐 Сайт: https://moscowzoo.ru\n\n"
        "*Адрес:*\n"
        "📍 Москва, ул. Большая Грузинская, 1\n\n"
        "*Программа опеки животных:*\n"
        "📧 Email: partner@moscowzoo.ru\n"
        "📞 Телефон: +7 (499) 255-60-34\n\n"
        "*Социальные сети:*\n"
        "📱 VK: vk.com/moscowzoo\n"
        "📸 Instagram: @moscowzoo_official"
    )

    await update.message.reply_text(contact_text, parse_mode='Markdown')


async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Ошибка: {context.error}", exc_info=True)

    if update and update.effective_user:
        try:
            await context.bot.send_message(
                chat_id=update.effective_user.id,
                text="⚠️ Произошла техническая ошибка. Пожалуйста, попробуйте /start",
                parse_mode='Markdown'
            )
        except:
            pass


# ==================== ГЛАВНАЯ ФУНКЦИЯ ====================
def main():
    if not TOKEN:
        print("❌ ОШИБКА: BOT_TOKEN не найден в .env файле")
        print("Создайте файл .env с содержанием: BOT_TOKEN=ваш_токен")
        return

    # Инициализация базы данных
    init_database()

    # Проверяем наличие папки с фото
    if not os.path.exists("animals"):
        print("⚠️  ВНИМАНИЕ: Папка 'animals' не найдена!")
        print("Создайте папку 'animals' и добавьте фото:")
        print("  tiger.jpg, bear.jpg, panda.jpg, fox.jpg, wolf.jpg, monkey.jpg")
        print("Или используйте скрипт для скачивания тестовых фото.")

    # Создание приложения
    app = Application.builder().token(TOKEN).build()

    # Регистрация обработчиков
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("contact", contact_command))
    app.add_handler(CallbackQueryHandler(button_handler))

    # Обработчик ошибок
    app.add_error_handler(error_handler)

    # Запуск бота
    print("=" * 50)
    print("✅ БОТ МОСКОВСКОГО ЗООПАРКА ЗАПУЩЕН")
    print("📸 Режим: с фото животных")
    print("🎨 Брендбук: соблюдены цвета и стиль")
    print("=" * 50)
    print("📱 В Telegram напишите /start для начала")

    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == '__main__':
    main()