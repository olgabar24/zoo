#!/usr/bin/env python3
"""
Скрипт для скачивания тестовых фото животных
"""

import os
import requests
from PIL import Image
import io

# Ссылки на фото животных (свободные для использования)
ANIMAL_PHOTOS = {
    'tiger.jpg': 'https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=800&h=400&fit=crop',
    'bear.jpg': 'https://images.unsplash.com/photo-1573920111312-04f1b25c6b85?w=800&h=400&fit=crop',
    'panda.jpg': 'https://images.unsplash.com/photo-1525385133512-2f3bdd039054?w=800&h=400&fit=crop',
    'fox.jpg': 'https://images.unsplash.com/photo-1516934024742-b461fba47600?w=800&h=400&fit=crop',
    'wolf.jpg': 'https://images.unsplash.com/photo-1519003722824-194d4455a60e?w=800&h=400&fit=crop',
    'monkey.jpg': 'https://images.unsplash.com/photo-1540573133985-87b6da6d54a9?w=800&h=400&fit=crop',
}


def download_photos():
    """Скачивает фото животных"""

    # Создаем папку если нет
    if not os.path.exists("animals"):
        os.makedirs("animals")
        print("✅ Создана папка 'animals'")

    downloaded = 0

    for filename, url in ANIMAL_PHOTOS.items():
        filepath = os.path.join("animals", filename)

        # Пропускаем если уже есть
        if os.path.exists(filepath):
            print(f"⚠️  Пропускаем {filename} (уже существует)")
            downloaded += 1
            continue

        try:
            print(f"⬇️  Скачиваю {filename}...")

            # Скачиваем изображение
            response = requests.get(url, timeout=10)
            response.raise_for_status()

            # Открываем и обрабатываем изображение
            img = Image.open(io.BytesIO(response.content))

            # Конвертируем в RGB если нужно
            if img.mode != 'RGB':
                img = img.convert('RGB')

            # Сохраняем
            img.save(filepath, 'JPEG', quality=85)

            print(f"✅ Сохранено: {filename} ({img.size[0]}x{img.size[1]})")
            downloaded += 1

        except Exception as e:
            print(f"❌ Ошибка при скачивании {filename}: {e}")

    return downloaded


def create_placeholder_photos():
    """Создает заглушки если не удалось скачать"""

    colors = [
        (255, 100, 100),  # Красный - тигр
        (139, 69, 19),  # Коричневый - медведь
        (255, 255, 255),  # Белый - панда
        (255, 140, 0),  # Оранжевый - лиса
        (128, 128, 128),  # Серый - волк
        (139, 90, 43),  # Коричневый - обезьяна
    ]

    animals = ['tiger', 'bear', 'panda', 'fox', 'wolf', 'monkey']
    emojis = ['🐯', '🐻', '🐼', '🦊', '🐺', '🐵']

    if not os.path.exists("animals"):
        os.makedirs("animals")

    for i, animal in enumerate(animals):
        filename = f"{animal}.jpg"
        filepath = os.path.join("animals", filename)

        # Создаем цветное изображение
        img = Image.new('RGB', (800, 400), color=colors[i])
        draw = ImageDraw.Draw(img)

        # Добавляем эмодзи
        try:
            font = ImageFont.truetype("arial.ttf", 120)
        except:
            font = ImageFont.load_default()

        # Текст
        text = emojis[i]
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]

        draw.text(
            ((800 - text_width) // 2, (400 - text_height) // 2),
            text,
            font=font,
            fill=(255, 255, 255)
        )

        # Сохраняем
        img.save(filepath, 'JPEG')
        print(f"✅ Создана заглушка: {filename}")


if __name__ == '__main__':
    print("=" * 50)
    print("СКРИПТ ДЛЯ ЗАГРУЗКИ ФОТО ЖИВОТНЫХ")
    print("=" * 50)

    try:
        # Пробуем скачать настоящие фото
        downloaded = download_photos()

        if downloaded < 6:
            print(f"\n⚠️  Скачано только {downloaded}/6 фото")
            print("Создаю цветные заглушки...")

            from PIL import ImageDraw, ImageFont

            create_placeholder_photos()

        print("\n✅ Готово! Фото животных в папке 'animals/'")
        print("Теперь можно запускать бота: python bot.py")

    except Exception as e:
        print(f"❌ Ошибка: {e}")
        print("\nСоздаю цветные заглушки...")

        from PIL import ImageDraw, ImageFont

        create_placeholder_photos()